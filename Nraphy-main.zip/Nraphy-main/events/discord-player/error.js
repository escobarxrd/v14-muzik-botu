module.exports = async (client, queue, error) => {

  client.logger.error(error);

};
